<?php
$servername = "localhost";
$username = "id3928671_levertkabi";
$password = "levertkabi";
$dbname = "id3928671_picknpaydatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $prodname = $_POST["prodname"];
    $prodinfo = $_POST["prodinfo"];
    $productimg = $_POST["productimg"];
    $price = $_POST["price"];
    $categoryID = $_POST["categoryID"];
    
	$sql = "INSERT INTO Product (prodname, prodinfo, price,categoryID)
	VALUES ('$prodname', '$prodinfo', '$price', '$categoryID')";
	
    if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>