<?php
$servername = "localhost";
$username = "id3928671_levertkabi";
$password = "levertkabi";
$dbname = "id3928671_picknpaydatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $username = $_POST["txtUsername"];
    $password = $_POST["txtPassword"];
    
    //$username = "levert";
    //$password = "levert";
    
	$sql = "SELECT * FROM User WHERE username = '$username' AND password = '$password'";
	//$sql = "SELECT * FROM User WHERE username = 'levert123okpo4' AND password = 'kabelevert'";
	$result = $conn->query($sql);
	$rowcount=mysqli_num_rows($result);
	
	//$query = $DB->query("SELECT * FROM User WHERE username = '$username' AND password = '$password'");
	
    echo ($rowcount);
    if($rowcount > 0 )
    {
        echo "success";
    }
    else
    {
        echo "unsucess";
    }
    
    //echo json_encode("Sucess");
    //echo ("success");
$conn->close();
?>