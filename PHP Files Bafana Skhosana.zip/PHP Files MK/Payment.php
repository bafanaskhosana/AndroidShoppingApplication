<?php
$servername = "localhost";
$username = "id4248010_bafana";
$password = "12345";
$dbname = "id4248010_picknpay";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    

    $sql = "SELECT * FROM Cart Where username='$username'";

	$result = $conn->query($sql);
	$rowcount=mysqli_num_rows($result);
	
	$count = 0;
	
	//$query = $DB->query("SELECT * FROM User WHERE username = '$username' AND password = '$password'");
	
    //echo ($rowcount);
    if($rowcount > 0 )
    {
        $product = array();
//echo "success";
echo("[");
        while($row = $result->fetch_assoc()) 
        {
            
         
        	$id = $row["id"];
            $prodName = $row["prodName"];
            $description = $row["description"];
	        $quantity = $row["quantity"];
            $price = $row["price"];
            $img_url = $row["img_url"];
	        $customer = $row["customer"];
	        $ordernumber = $row["ordernumber"];
                   
            $product["id"] = $id;
            $product["name"] =$prodName;
            $product["description"]= $description;
            $product["quantity"] = $quantity;
            $product["price"] = $price;
            $product["img_url"]= $img_url;
            $product["ordernumber"]= $ordernumber;
            echo json_encode($product);
            $count = $count + 1;
        }
    }
    else
    {
        echo "unsucess";
    }
    
    
    
    
    
    echo("]");
$conn->close();
?>