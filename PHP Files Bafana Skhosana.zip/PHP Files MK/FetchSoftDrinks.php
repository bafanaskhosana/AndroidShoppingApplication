<?php
$servername = "localhost";
$username = "id3928671_levertkabi";
$password = "levertkabi";
$dbname = "id3928671_picknpaydatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $prodName = $_POST["txtName"];
    $prodDesc = $_POST["txtDesc"];
    $prodQty = $_POST["txtQty"];
    $prodPrice = $_POST["txtPrice"];
    $prodImageUrl = $_POST["txtImageUrl"];
    $prodCustomer = $_POST["txtCustomer"];
    
	$sql = "INSERT INTO Cart (prodName, description, quantity, price, img_url, customer)
	VALUES ('$prodName', '$prodDesc', '$prodQty', '$prodPrice', '$prodImageUrl', '$prodCustomer')";
    
    if (!mysqli_query($conn,$sql)) {
    echo "failed";
} else {
    echo "success";
}

$conn->close();
?>