<?php
$servername = "localhost";
$username = "id3928671_levertkabi";
$password = "levertkabi";
$dbname = "id3928671_picknpaydatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $fName = $_POST["fName"];
    $lName = $_POST["lName"];
    $email = $_POST["email"];
    $pNumber = $_POST["pNumber"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    
  
    
	$sql = "INSERT INTO User (fName, lName, email, pNumber, username, password)
	VALUES ('$fName', '$lName', '$email', '$pNumber', '$username', '$password' )";
	
    
    if (!mysqli_query($conn,$sql)) {
    echo "failed";
} else {
    echo "success";
}

$conn->close();
?>