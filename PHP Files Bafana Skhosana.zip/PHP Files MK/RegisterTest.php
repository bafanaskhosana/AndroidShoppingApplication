<?php
$servername = "localhost";
$username = "id3928671_levertkabi";
$password = "levertkabi";
$dbname = "id3928671_picknpaydatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO User (name, age, username, password)
VALUES ('John', 'Doe', 'john@example.com', 'John')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

//PArt 2

<?php
$servername = "localhost";
$username = "id3928671_levertkabi";
$password = "levertkabi";
$dbname = "id3928671_picknpaydatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $username = $_POST["txtUsername"];
    $password = $_POST["txtPassword"];
    
    //$username = "levert";
    //$password = "levert";
    
	$sql = "SELECT * FROM User WHERE username = '$username' AND password = '$password'";
	$result = $conn->query($sql);
	
    if($result)
    {
        if ($result->num_rows > 0)
    	{
    	    $user = array();
        		while($row = $result->fetch_assoc()) 
        		{
                   // $name = $row["name"];
                   // $age = $row["age"];
                   // $username = $row["username"];
                    //$roleID = $row["roleID"];
                    
                    
                    
                    //$user["name"] = $name;
                    //$user["age"] = $age;
                   // $user["username"] = $username;
                   // $user["password"] = $password;
                    //$user["roleID"]= $row["roleID"];
                }
        }
    	else 
    	{
            echo "0 results";
    	}
    }
    else
    {
        echo "Database error.";
    }
    
    //echo json_encode("Sucess");
    echo ("success");
$conn->close();
?>