<?php
$servername = "localhost";
$username = "id3928671_levertkabi";
$password = "levertkabi";
$dbname = "id3928671_picknpaydatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $username = $_POST["txtUsername"];
    
	$sql = "DELETE FROM Cart
	WHERE customer = '$username'";
	
	$result = $conn->query($sql);
	//$num_rows = mysql_num_rows($result);
	
	//$rowcount=mysqli_num_rows($result);
	
   // echo ($rowcount);
	
	//$result = mysql_query($query);
//	$fetch = mysql_fetch_row($result);
//	$rows = mysql_num_rows( mysql_query($query) );
	 
	
  //  echo($rows);
    if (!mysqli_query($conn,$sql)) {
    echo "success";
} else {
    echo "fail";
}

$conn->close();
?>