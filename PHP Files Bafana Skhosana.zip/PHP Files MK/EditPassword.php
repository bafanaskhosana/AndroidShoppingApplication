<?php
$servername = "localhost";
$username = "id4248010_bafana";
$password = "12345";
$dbname = "id4248010_picknpay";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $username = $_POST["txtUsername"];
    $password = $_POST["txtPassword"];
    
	$sql = "UPDATE User
	SET password = '$password'
	WHERE username = '$username'";
	
	$result = $conn->query($sql);
	
    if (!mysqli_query($conn,$sql)) {
    echo "Update Successful";
} else {
    echo "Update Unsuccessful";
}

$conn->close();
?>