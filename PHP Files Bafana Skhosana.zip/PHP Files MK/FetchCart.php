<?php
$servername = "localhost";
$username = "id3928671_levertkabi";
$password = "levertkabi";
$dbname = "id3928671_picknpaydatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    //$username = $_POST["txtUsername"];
    
    //$username = "levert";
 
    
	//$sql = "SELECT * FROM Cart WHERE customer = '$username'";
	//$sql = "SELECT * FROM Cart WHERE username = 'levert123okpo4' AND password = 'kabelevert'";
    $sql = "SELECT * FROM Cart";

	$result = $conn->query($sql);
	$rowcount=mysqli_num_rows($result);
	
	//$query = $DB->query("SELECT * FROM User WHERE username = '$username' AND password = '$password'");
	
    //echo ($rowcount);
    if($rowcount > 0 )
    {
        $product = array();
//echo "success";
        while($row = $result->fetch_assoc()) 
        {
        	$id = $row["id"];
            $prodName = $row["prodName"];
            $description = $row["description"];
	        $quantity = $row["quantity"];
            $price = $row["price"];
            $img_url = $row["img_url"];
	        $customer = $row["customer"];
	        $ordernumber = $row["ordernumber"];
                   
            $product["id"] = $id;
            $product["name"] =$prodName;
            $product["description"]= $description;
            $product["quantity"] = $quantity;
            $product["price"] = $price;
            $product["img_url"]= $img_url;
            $product["ordernumber"]= $ordernumber;
        }
    }
    else
    {
        echo "unsucess";
    }
    
    echo("[");
    
    echo json_encode($product);
    
    echo("]");
$conn->close();
?>