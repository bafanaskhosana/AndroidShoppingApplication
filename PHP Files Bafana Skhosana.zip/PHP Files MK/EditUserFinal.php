<?php
$servername = "localhost";
$username = "id3928671_levertkabi";
$password = "levertkabi";
$dbname = "id3928671_picknpaydatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $name = $_POST["name"];
    $lname = $_POST["lname"];
    $email = $_POST["email"];
    $title = $_POST["title"];
    $cellno = $_POST["cellno"];
    $username = $_POST["username"];
  
    
	$sql = "UPDATE User
	SET name = '$name', lname = '$lname', email = '$email', title  = '$title', cellno = '$cellno '
	WHERE name = '$username'";
	
    
    if ($conn->query($sql) === TRUE) {
    echo "Record Edited";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>