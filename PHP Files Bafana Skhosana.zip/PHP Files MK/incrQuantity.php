<?php
$servername = "localhost";
$username = "id4248010_bafana";
$password = "12345";
$dbname = "id4248010_picknpay";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$pid = $_POST["txtPid"];
    $sql = "UPDATE Cart SET quantity = quantity + 1 WHERE id = '$pid'";

	$result = $conn->query($sql);
	$rowcount=mysqli_num_rows($result);


$conn->close();
?>