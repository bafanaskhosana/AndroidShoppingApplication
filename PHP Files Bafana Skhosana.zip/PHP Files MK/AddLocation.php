<?php
$servername = "localhost";
$username = "id4248010_bafana";
$password = "12345";
$dbname = "id4248010_picknpay";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $address = $_POST["address"];
    $contact = $_POST["conatact"];
    $time = $_POST["time"];
    
    
	$sql = "INSERT INTO OrderItem (address, conatact, time)
	VALUES ('$address', '$contact', '$time', )";
    
    if (!mysqli_query($conn,$sql)) {
    echo "failed";
} else {
    echo "success";
}

$conn->close();
?>