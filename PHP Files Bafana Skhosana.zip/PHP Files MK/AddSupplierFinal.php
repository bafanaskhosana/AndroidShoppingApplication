<?php
$servername = "localhost";
$username = "id3928671_levertkabi";
$password = "levertkabi";
$dbname = "id3928671_picknpaydatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $supplierName = $_POST["supplierName"];
    $city = $_POST["city"];
    $password = $_POST["password"];
    
  
    
	$sql = "INSERT INTO Supplier(supplierName, city, password, roleID)
	VALUES ('$supplierName', '$city', '$password', 3)";
	
    
    if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>