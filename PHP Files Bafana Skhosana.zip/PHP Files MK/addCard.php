<?php
$servername = "localhost";
$username = "id4248010_bafana";
$password = "12345";
$dbname = "id4248010_picknpay";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    
    $type = $_POST["txtType"];
    $holder = $_POST["txtHolder"];
    $number = $_POST["txtNumber"];
    $month = $_POST["txtExpMonth"];
    $year = $_POST["txtExpYear"];
    $cvc = $_POST["txtCvc"];
    
  
    
	$sql = "INSERT INTO Payment (cardNo, cardHolder, cartType, cvc, expMonth, expYear)
	VALUES ('$number', '$holder', '$type', '$cvc', '$month', '$year' )";
	
    
    if (!mysqli_query($conn,$sql)) {
    echo "failed";
} else {
    echo "success";
}

$conn->close();
?>