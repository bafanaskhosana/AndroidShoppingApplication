<?php
$servername = "localhost";
$username = "id4248010_bafana";
$password = "12345";
$dbname = "id4248010_picknpay";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
    $sql = "SELECT * FROM Product WHERE categoryID = '1'";

	$result = $conn->query($sql);
	$rowcount=mysqli_num_rows($result);

    if($rowcount > 0 )
    {
        //$product[] = array();
//echo "success";
        while($row = $result->fetch_assoc()) 
        {
        	$ProductID = $row["productid"];
            $ProductName = $row["prodname"];
            $Description = $row["description"];
            $Price = $row["price"];
            $IMG_URL = $row["img_url"];
	        $cartid = $row["cartid"];
                   
            /*$product["id"] = $id;
            $product["name"] =$prodName;
            $product["description"]= $description;
            $product["quantity"] = $quantity;
            $product["price"] = $price;
            $product["img_url"]= $img_url;
            $product["ordernumber"]= $ordernumber;*/
            
            $product[] = array('ProductID' => $ProductID, 'ProductName' => $ProductName, 'Description' => $Description, 'Price' => $Price, 'IMG_URL' => $IMG_URL, 'cartid' => $cartid);
        }
    }
    else
    {
        echo "unsucess";
    }
    
    //echo("[");
    
    echo json_encode($product);
    
    //echo("]");
$conn->close();
?>