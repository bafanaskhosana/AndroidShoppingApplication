package com.bafana.Interfaces;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by Reverside on 2018/01/31.
 */

public class Users implements Serializable {

    @SerializedName ("CustomerID")
    public int id;

    @SerializedName("FName")
    public String FName;

    @SerializedName("LName")
    public String LName;

    @SerializedName("UserName")
    public String username;

    @SerializedName("Email")
    public String email;


}
