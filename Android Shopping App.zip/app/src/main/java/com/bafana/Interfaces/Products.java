package com.bafana.Interfaces;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by Reverside on 2018/01/31.
 */


public class Products implements Serializable{

    @SerializedName("ProductID")
    public int id;

    @SerializedName("ProductName")
    public String name;

    @SerializedName("Description")
    public String description;

    @SerializedName("Price")
    public double price;

    @SerializedName("IMG_URL")
    public String img_url;
}
